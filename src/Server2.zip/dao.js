var Datastore = require('nedb');
var path = require('path');
var db = {
    batch: new Datastore({ filename: path.join(__dirname + '/db/batch'), autoload: true }),
    batch_chapter: new Datastore({ filename: path.join(__dirname + '/db/batch_chapter'), autoload: true }),
    chapter: new Datastore({ filename: path.join(__dirname + '/db/chapter'), autoload: true }),
    course: new Datastore({ filename: path.join(__dirname + '/db/course'), autoload: true }),
    user: new Datastore({ filename: path.join(__dirname + '/db/user'), autoload: true })
};

module.exports = db;