var express = require("express");
var bodyParser = require("body-parser");
var cors = require("cors");
var mountRoutes = require("./routes");



var app = express();
app.use(bodyParser.json());
app.use(cors());
mountRoutes(app);


app.get("*",(req,res)=>{

    res.status(404).json({error:'Page not found',path:req.url});
});

app.listen(3010,()=>{
    console.log("App running at 3010");
});