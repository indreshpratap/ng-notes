var express = require('express');
var crypto = require('crypto');
var db = require('./dao');

var user = express.Router();
var admin = express.Router();

module.exports = function mountRoutes(app) {
    var api = express.Router();
    api.use('/admin', admin);
    api.use('/user', user);

    app.use('/ngnotes/api', api);
};

function getJson(err, data) {
    if (err) {
        console.log(new Date(), err);
        return { status: 500 };
    } else {
        return { status: 200 };
    }
}

function DB_OK(err, res, data) {
    let json = getJson(err);
    if (data) { json.data = data; }
    res.json(json);
}

function getHash(str) {
    return crypto.createHash('md5').update(str).digest("hex");
}
/* End of helper functions */

admin.post('/reg-batch', (req, res) => {
    // Todo: Add duplicate check
    let body = req.body;
    body.active = true;
    body.created_date = new Date();
    db.batch.insert(body, (err) => { DB_OK(err, res, null); });
});
admin.post('/reg-user', (req, res) => {
    // Todo: Add duplicate check, hash password
    let body = req.body;
    body.active = true;
    body.created_date = new Date();
    body.reset_required = true;
    let raw = body.email.substring(0, 5);
    body.password = getHash('12345');
    db.user.insert(body, (err) => { DB_OK(err, res, null); });
});

admin.post('/reg-course', (req, res) => {
    // Todo: Add duplicate check
    let body = req.body;
    body.active = true;
    body.created_date = new Date();
    db.course.insert(body, (err) => { DB_OK(err, res, null); });
});

admin.post('/reg-chapter', (req, res) => {
    // Todo: Add duplicate check
    let body = req.body;
    body.active = true;
    body.created_date = new Date();
    db.chapter.insert(body, (err) => { DB_OK(err, res, null); });
});

admin.post('/grant-batch-chapter', (req, res) => {
    // Todo: Add duplicate check
    let body = req.body;
    db.batch_chapter.findOne({ "batch_id": body.batch_id, "course_id": body.course_id },
        (err, doc) => {
            if (doc) {
                let _id = doc._id;
                db.batch_chapter.update({ _id: _id },
                    {
                        $push: { chapters: { $each: body.chapters } }
                    }, {}, () => { DB_OK(null, res, null) });
            } else {
                body.active = true;
                body.created_date = new Date();
                db.batch_chapter.insert(body, (err, doc) => { DB_OK(err, res, { id: doc._id }) });
            }
        });
});

admin.get("/get-batch",(req,res)=>{
    db.batch.find({},{batch_name:1},(err,data)=>{ DB_OK(err,res,data)});
});

admin.get("/get-course",(req,res)=>{
    db.course.find({},{courseName:1},(err,data)=>{ DB_OK(err,res,data)});
});

admin.get('/chapters-for-grant/:course_id', (req, res) => {
    let { course_id } = req.params;
    db.chapter
        .find({ course_id: course_id, active: true }, { title: 1, access_type: 1, seq_order: 1 })
        .sort({ seq_order: 1 })
        .exec((err, docs) => { DB_OK(err, res, docs) });
});

admin.get("/granted-chapters/:course_id/:batch_id", (req, res) => {
    let { course_id, batch_id } = req.params;
    db.batch_chapter.find({ course_id: course_id, batch_id: batch_id }, { chapters: 1, _id: 0 },
        (err, docs) => { DB_OK(err, res, docs) });
});
